print("================================")
print("     RULE-BASED AI CHATBOT")
print("================================")
print("Type 'bye' to exit\n")

while True:
    user = input("You: ").lower().strip()

    # Remove punctuation
    user = user.replace("?", "").replace("!", "").replace(".", "")

    # Greetings
    if user == "hello" or user == "hi":
        print("Bot: Hello! How can I help you?")

    # Asking name
    elif user == "what is your name":
        print("Bot: I am a Rule-Based AI Chatbot.")

    # Asking about AI
    elif user == "what is ai":
        print("Bot: AI stands for Artificial Intelligence.")

    # Asking health
    elif user == "how are you":
        print("Bot: I am fine and ready to help you!")

    # Exit
    elif user == "bye" or user == "exit":
        print("Bot: Goodbye! Have a nice day.")
        break

    # Unknown input
    else:
        print("Bot: Sorry, I don't understand that.")